/**
 * 自己动手写操作系统
 *
 * 二级加载部分，用于实现更为复杂的初始化、内核加载的工作。
 *
 * 作者：李述铜
 * 联系邮箱: 527676163@qq.com
 */
#ifndef LOADER_H
#define LOADER_H

#endif // LOADER_H
