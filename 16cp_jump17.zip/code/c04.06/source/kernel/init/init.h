/**
 * 内核初始化以及测试代码
 *
 * 作者：李述铜
 * 联系邮箱: 527676163@qq.com
 */
#ifndef __INIT_H__
#define __INIT_H__


#endif // INIT_H