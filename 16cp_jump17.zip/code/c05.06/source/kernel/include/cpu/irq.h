/**
 * 中断处理
 *
 * 作者：李述铜
 * 联系邮箱: 527676163@qq.com
 */
#ifndef IRQ_H
#define IRQ_H

void irq_init (void);

#endif
